const { Client, IntentsBitField, ActivityType } = require('discord.js');
const config = require('./config.js');
const welcome = require('./src/welcome.js');


const client = new Client({
  intents: [
    IntentsBitField.Flags.Guilds,
    IntentsBitField.Flags.GuildMembers,
    IntentsBitField.Flags.GuildMessages,
    IntentsBitField.Flags.GuildPresences,
    IntentsBitField.Flags.MessageContent,
  ],
});

client.on('ready', async (c) => {
  console.log(`✅ ${c.user.tag} jest teraz online!`);

  const activities = [
    { name: 'FiveM', type: ActivityType.Playing },
    { name: 'Community', type: ActivityType.Watching },
  ];
  let index = 0;

  setInterval(() => {
    client.user.setActivity(activities[index]);
    index = (index + 1) % activities.length;
  }, 10 * 1000);

  try {
    console.log('Ładowanie modułów...');

    welcome(client);
    
    console.log('✅ Wszystkie moduły zostały załadowane pomyślnie!');
  } catch (error) {
    console.error('❗Błąd podczas inicjalizacji modułów:', error);
  }
});


client.login(config.token);

module.exports = { 
    token: "MTMxMzk4OTYxODQzMzI2MTU3OQ.GAcHsw.9CeZPpk5T9-Txev6-Ihi96IY5iICA6yB58KNFU",
    guildId: "1192897383428800532",
    welcome: {
        channelId: "1192897383919517731",
        embed: {
            color: "#ff0000",
            title: "NAZWA_SERWERA",
            description: "Cześć, {user}! 🎉\nMiło Cię widzieć na **NAZWA_SERWERA!**\n\n**Obecnie mamy {memberCount} członków!**",
            fields: [
                {
                    name: "👤 Użytkownik",
                    value: "{user}",
                    inline: true
                },
                {
                    name: "📅 Data dołączenia",
                    value: "{joinDate}",
                    inline: true
                }
            ],
            thumbnail: true, // Jeśli ustawisz na false, nie będzie miniaturki
            timestamp: true  // Jeśli ustawisz na false, nie będzie znacznika czasu
        }
    }
};

const { EmbedBuilder } = require('discord.js');
const config = require('../config.js');

module.exports = function(client) {
    client.on('guildMemberAdd', async (member) => {
        const welcomeConfig = config.welcome;
        if (!welcomeConfig) return;

        const channel = member.guild.channels.cache.get(welcomeConfig.channelId);
        if (!channel) return;

        const embedData = welcomeConfig.embed;
        const memberCount = member.guild.memberCount;

        const welcomeEmbed = new EmbedBuilder()
            .setColor(embedData.color)
            .setTitle(embedData.title)
            .setDescription(embedData.description
                .replace("{user}", `<@${member.user.id}>`)
                .replace("{memberCount}", memberCount))
            .addFields(embedData.fields.map(field => ({
                name: field.name,
                value: field.value
                    .replace("{user}", `<@${member.user.id}>`)
                    .replace("{joinDate}", `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`),
                inline: field.inline
            })));

        if (embedData.thumbnail) {
            welcomeEmbed.setThumbnail(member.user.displayAvatarURL({ dynamic: true }));
        }

        if (embedData.timestamp) {
            welcomeEmbed.setTimestamp();
        }

        channel.send({ embeds: [welcomeEmbed] });
    });
};
